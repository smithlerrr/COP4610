#include <unistd.h>

int main(void){
	syscall(322);
	return 0;
}
