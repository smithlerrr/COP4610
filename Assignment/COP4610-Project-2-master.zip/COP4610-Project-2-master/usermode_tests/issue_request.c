#include <unistd.h>	

int main(void){

	syscall(323, 'A', 1, 0);
	syscall(323, 'M', 1, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	syscall(323, 'A', 1, 3);
	syscall(323, 'L', 1, 5);
	syscall(323, 'C', 2, 1);
	syscall(323, 'A', 3, 2);
	syscall(323, 'L', 3, 5);
	syscall(323, 'C', 4, 1);
	syscall(323, 'C', 5, 4);
	syscall(323, 'L', 5, 4);
	syscall(323, 'A', 5, 4);
	syscall(323, 'L', 2, 5);
	
	return 0;
}
