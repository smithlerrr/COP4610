#include <unistd.h>

int main(){
	syscall(321);
	return 0;
}
