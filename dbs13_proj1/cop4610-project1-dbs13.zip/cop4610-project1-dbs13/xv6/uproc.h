struct uproc
{
	int pid;
	int state;
	uint sz;
	char name[16];
};

